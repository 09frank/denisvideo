<?php

include('../includes/conexao.php');

?>
<!DOCTYPE html>
<html>

<head>
	<?php include('../includes/head.php'); ?>
</head>

<body>
	<div class="container">
		<?php include('../includes/menu.php'); ?>
		<div class="col-md-9">
			<h3>Administração</h3>
			
			
		</div>
	</div>
	<?php include('../includes/js.php'); ?>

</body>

</html>