/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  frank
 * Created: 12/12/2019
 */
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of categorias
-- ----------------------------
INSERT INTO `categorias` VALUES ('1', 'Musica');
INSERT INTO `categorias` VALUES ('2', 'Jogos');
INSERT INTO `categorias` VALUES ('3', 'Lives');
INSERT INTO `categorias` VALUES ('4', 'Conhecimentos');
INSERT INTO `categorias` VALUES ('5', 'Animações');

----------------------------------------------------------------

CREATE TABLE `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
    `autor` varchar(50) DEFAULT NULL,
  `data` date DEFAULT NULL,
    `curtidas`int(11) DEFAULT NULL,
    `visualizações` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `videos` VALUES ()